/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Penilaian;
import Perhitungan.Penjumlahan;
import java.util.Scanner;

/**
 *
 * @author ahnaffaiz
 */
public class Penilaian {
    
    //attribute
    //encapsulation
    public String nama;
    public int score; 
    public int level, menu;
    public int lives;
    
    
    //methods untuk menampilkan menu
    public void getMenu() {
        
        Penjumlahan jumlah = new Penjumlahan();
        Scanner myNama = new Scanner(System.in);
        
        this.score = 0;
        this.level = 1;
        this.lives = 3;
        
        menu = 0;
        while (menu !=1 || menu!=2 || menu !=3){
            System.out.println("*******************************");
            System.out.println("Game Math");
            System.out.println("*******************************");
            System.out.println("1. Penjumlahan");
            System.out.println("2. Pengurangan");
            System.out.println("3. Keluar");
            System.out.print("Pilih menu: ");
            this.menu = myNama.nextInt();
            
            if (menu==1){
                jumlah.level();
            } else if (menu==2){
                //untuk pengurangan
                System.out.println("untuk pengurangan");
            } else if (menu==3){
                //untuk keluar
                System.out.println("untuk keluar");
            } else {
                menu = 0;
            }
            break;
        }    
    }
    
    
    
    
   
    
    public void getResult(String a){
        String namaku = a; 
        if (score > 300) {
            System.out.println("Selamat " + namaku + ", Anda telah menyelesaikan soal penjumlahan dengan baik. Silakan dicoba soal pengurangan ya");
        }
        else {
            System.out.println("Hai, " + namaku +  ", jangan menyerah ya untuk mencoba lagi");
        }
    }
    
    
}
