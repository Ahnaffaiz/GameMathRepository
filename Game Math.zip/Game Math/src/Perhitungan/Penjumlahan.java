/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Perhitungan;
import Penilaian.Penilaian;
import game.math.MainClass;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author ahnaffaiz
 */
public class Penjumlahan extends Penilaian {
    
    //attribute
    //encapsulation
    private int bilPertama, bilKedua;
    
    //methods level1
    public void level(){
        
        //instansiasi
        Random rand = new Random();
        Scanner myJawab = new Scanner(System.in);
        MainClass myclass = new MainClass();
        //
        int score = this.score;
        int lives = this.lives;
        int level = this.level;
        String nama = this.nama;
        
            
            
        //level1
        while(score <= 100  && lives >= 1){
            this.bilPertama = rand.nextInt(11);
            this.bilKedua = rand.nextInt(11);
               
            System.out.println("berapa hasil dari " + bilPertama + " + " + bilKedua + " ?" );
            System.out.print("jawab: ");
            int jawab = myJawab.nextInt();
                
            if (bilPertama + bilKedua == jawab){
                score += 4;
                System.out.print("Selamat, " + "Anda Benar, ");
                System.out.println("[Skor: " + score + "]" + "[Live: " + lives + " ]" + "[level: " + level);
            } else {
                score -=1;
                lives -= 1;
            }
                
        }
        
        //level2
        while(score >= 101  && score<=200 && lives >= 1){
            level = 2;
            this.bilPertama = rand.nextInt((-1) - (-11));
            this.bilKedua = rand.nextInt((-1) - (-11));
               
            System.out.println("berapa hasil dari (" + bilPertama + ") + (" + bilKedua + ") ?" );
            System.out.print("jawab: ");
            int jawab = myJawab.nextInt();
                
            if (bilPertama + bilKedua == jawab){
                score += 4;
                System.out.println("[Skor: " + score + "]" + "[Live: " + lives + " ]" + "[level: " + level);
            } else {
                score -=1;
                lives -= 1;
            }
                
        }
        
        //level3
        while(score >= 201  && score<=300 && lives >= 1){
            level = 3;
            this.bilPertama = rand.nextInt((10) - (-10));
            this.bilKedua = rand.nextInt((10) - (-10));
               
            System.out.println("berapa hasil dari " + bilPertama + " + " + bilKedua + " ?" );
            System.out.print("jawab: ");
            int jawab = myJawab.nextInt();
                
            if (bilPertama + bilKedua == jawab) {
                score += 4;
                System.out.println("[Skor: " + score + "]" + "[Live: " + lives + " ]" + "[level: " + level);
            } else {
                score -=1;
                lives -= 1;
            }
                
        }
           
    }
    
    
}
