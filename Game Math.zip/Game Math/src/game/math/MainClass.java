package game.math;


import Penilaian.Penilaian;
import Perhitungan.Penjumlahan;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ahnaffaiz
 */
public class MainClass {
    
    
    public static void main(String[] args) {
        Penilaian nilai = new Penilaian();
        Penjumlahan jumlah = new Penjumlahan();
        Scanner myNama = new Scanner(System.in);
        
        System.out.println("*******************************");
        System.out.println("Game Math");
        System.out.println("*******************************");
        System.out.print("Masukkan nama Anda: ");
        
        //memberikan nilai default
        String nama = myNama.nextLine();
        nilai.getMenu();
        nilai.getResult(nama);
    }
}
